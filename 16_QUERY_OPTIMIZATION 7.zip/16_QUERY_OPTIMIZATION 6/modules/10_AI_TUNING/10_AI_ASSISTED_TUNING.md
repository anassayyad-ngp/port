# Module 10: AI-Assisted Query Tuning Workflow (Safe Copilot Usage)

## Business Objective
Use Large Language Models (LLMs) as an accelerator for EXPLAIN interpretation, query-rewrite exploration, and syntax translation while preserving strict human ownership of correctness, physical design, and production risk.

An LLM can generate plausible SQL without knowing:

- the real data distribution;
- current statistics;
- index definitions;
- lock behavior;
- write volume;
- replication topology;
- workload concurrency;
- engine version;
- cloud billing model.

Therefore:

> **AI proposes. The database proves. The engineer decides.**

## The Safe Copilot Workflow

```mermaid
graph LR
    A[Query + Schema + EXPLAIN] -->|Constrained Prompt| B[LLM Suggestion]
    B --> C{Human Validation}
    C -- Invalid Syntax / Wrong Assumption --> D[Reject]
    C -- Performance Smell Found --> E[Rewrite / Re-Prompt]
    C -- Plausible --> F[Staging Benchmark]
    F --> G{Result + Plan Equivalent?}
    G -- No --> D
    G -- Yes --> H[CI/CD Performance Gate]
    H --> I[Production Deployment + Monitoring]
```

## Poor Version: The Hallucinated Optimization

```sql
-- AI suggestion copied directly into PostgreSQL:
SELECT /*+ INDEX(o idx_orders) */
       *
FROM orders o
WHERE o.user_id = 123;
```

**Impact:** PostgreSQL does not provide Oracle-style optimizer hints through this comment syntax. More importantly, blindly copying an AI-generated index recommendation can introduce unnecessary write amplification, storage growth, WAL pressure, and replication lag.

A second failure mode is a massive covering index:

```sql
CREATE INDEX idx_orders_covering
ON orders(user_id)
INCLUDE (
    col1, col2, col3, col4, col5,
    col6, col7, col8, col9, col10,
    col11, col12, col13, col14, col15
);
```

The read query may become dramatically faster while the write workload becomes materially more expensive.

## Optimized Version: Validated Rewrite

```sql
-- Human-validated rewrite:
SELECT
    o.order_id,
    o.created_at
FROM orders AS o
WHERE o.user_id = 123;
```

The index decision is then evaluated separately:

```sql
CREATE INDEX idx_orders_user_created
ON orders(user_id, created_at DESC);
```

The index is not accepted because an LLM suggested it. It is accepted only if:

1. it matches the actual predicate/order pattern;
2. the left-most prefix supports the workload;
3. the resulting plan improves under representative data;
4. write amplification is acceptable;
5. the index is not redundant;
6. the business result remains unchanged.

## Prompt Design: Give the Model the Physical Context

A weak prompt:

```text
Optimize this SQL.
```

A production-grade prompt supplies:

- database engine and exact version;
- SQL text;
- schema;
- relevant indexes;
- row counts;
- approximate cardinality/skew;
- EXPLAIN output;
- workload frequency;
- read/write ratio;
- latency budget;
- constraints such as "do not change schema."

Example:

```text
Engine: PostgreSQL 16
Table: orders, approximately 80M rows
Write rate: 5,000 inserts/sec
Query frequency: 2,000 executions/sec
Latency budget: P95 < 100 ms
Indexes: ...
EXPLAIN (ANALYZE, BUFFERS): ...

Do not invent indexes or optimizer hints.
First identify the highest-cost node.
Then provide at most two candidate changes.
For every index proposal, estimate the write-side risk and explain
which query predicates it supports.
```

## Prompt Template 1: EXPLAIN Plan Translation

> "Act as a Principal Database Engineer. I am pasting a PostgreSQL `EXPLAIN (ANALYZE, BUFFERS)` output below. Translate the physical plan into engineering language. Identify the exact node responsible for the largest amount of work, compare estimated versus actual rows, explain why the optimizer likely selected this path, and list exactly two improvements worth testing. Do not invent engine features or recommend changes without evidence. EXPLAIN: [PASTE EXPLAIN HERE]"

## Prompt Template 2: Index Suggestion Validation

> "I am considering `CREATE INDEX idx_x ON table(a, b, c)`. Here is the table schema, existing indexes, row count, write rate, and the top three queries using this table: [PASTE CONTEXT]. Evaluate the index using the left-most prefix rule, selectivity, ordering requirements, covering behavior, redundancy, storage, and write amplification. Do not suggest a replacement index until you have identified which of the three queries the proposed index can actually support."

## Prompt Template 3: Anti-Pattern Detection

> "Review the following SQL against `PERFORMANCE_SMELLS.md`. Do not rewrite it yet. Identify violations involving implicit conversions, non-SARGable predicates, unnecessary DISTINCT, OR predicates, correlated subqueries, large OFFSET pagination, SELECT *, missing join conditions, and nullable NOT IN semantics. For every finding, quote only the relevant SQL fragment, classify the smell, explain the physical consequence, and state whether it is definitely harmful or merely worth investigating. Query: [PASTE QUERY HERE]"

## Prompt Template 4: Cross-Engine Porting

> "I am migrating this Snowflake query to BigQuery. Identify engine-specific syntax and physical-performance differences involving date/time functions, JSON extraction, window functions, NULL semantics, partition pruning, clustering, and aggregation. Separate 'will not execute' issues from 'will execute but may perform poorly' issues. Do not silently change business logic. Query: [PASTE QUERY HERE]"

## Prompt Template 5: Devil's Advocate Rewrite

> "I optimized this PostgreSQL query by introducing a CTE and a Hash Join: [PASTE QUERY]. Act as a strict production DBA and attempt to disprove my optimization. Identify data distributions, skew, cardinality-estimation errors, memory limits, hash spills, CTE materialization behavior, concurrency effects, and write/read trade-offs that could make the new plan worse. Do not assume the rewrite is better. Give me the exact staging experiments required to prove or reject it."

## Red Flags for Hallucinated Optimizations

### 1. Magic Optimizer Hints

```sql
SELECT /*+ INDEX(table index_name) */
...
```

Treat engine-specific hints as suspect until verified against the exact database version and configuration.

### 2. Massive Covering Indexes

```sql
CREATE INDEX ...
INCLUDE (col1, col2, ... col20);
```

A covering index can be correct, but "cover everything" is not a tuning strategy. Evaluate:

```text
read benefit
    vs.
index storage + write amplification + WAL/redo + vacuum/maintenance
```

### 3. Phantom Functions

LLMs frequently mix dialects:

- `DATE_TRUNC()` behavior differs by engine;
- `STRING_AGG()` syntax differs by engine;
- JSON operators differ;
- timestamp/time-zone semantics differ;
- optimizer hint syntax differs.

A query that looks syntactically plausible is not evidence of portability.

### 4. Fake EXPLAIN Interpretation

Do not accept:

```text
"Index Scan is always faster than Seq Scan."
```

A sequential scan is often optimal when a large percentage of the table is required.

### 5. Benchmark-Free Claims

Reject:

```text
"This index will make the query 10x faster."
```

unless the claim is backed by an actual plan and benchmark under representative data.

## Mandatory Human Validation Checklist

Before applying any LLM-generated SQL to production:

- [ ] Confirm the exact database engine and version.
- [ ] Compare the proposed syntax with official engine documentation.
- [ ] Verify the result set is logically equivalent using `EXCEPT`, `MINUS`, or an equivalent deterministic comparison.
- [ ] Check all functions applied to filtered columns for SARGability.
- [ ] Compare estimated and actual rows in `EXPLAIN ANALYZE`.
- [ ] Verify every suggested index against existing indexes.
- [ ] Evaluate left-most prefix and ordering requirements.
- [ ] Estimate write amplification and storage impact.
- [ ] Test the query against representative data volume and skew.
- [ ] Capture `EXPLAIN (ANALYZE, BUFFERS)` before and after.
- [ ] Run the relevant CI/CD performance gate.
- [ ] For high-write tables, run a write-load test before approving new DDL.
- [ ] Monitor production after deployment for plan, latency, I/O, and replication changes.

## Result Verification Pattern

For equivalent SELECT statements:

```sql
(
    SELECT ...
)
EXCEPT
(
    SELECT ...
);
```

Then run the reverse comparison as well:

```sql
(
    SELECT ...
)
EXCEPT
(
    SELECT ...
);
```

For duplicate-sensitive logic, `EXCEPT` alone is insufficient because it is set-based. Use an explicit duplicate-aware comparison when multiplicity is part of the business result.

## AI-Assisted Tuning and PERFORMANCE_SMELLS.md

The model should not replace your performance catalog.

Use `PERFORMANCE_SMELLS.md` as a deterministic first-pass checklist:

```text
LLM hypothesis
      ↓
PERFORMANCE_SMELLS.md
      ↓
EXPLAIN evidence
      ↓
staging benchmark
      ↓
result-equivalence check
      ↓
CI performance gate
      ↓
production monitoring
```

The LLM is therefore one stage inside the engineering workflow, not the workflow itself.

## Real-World Incident: The Covering-Index Failure Mode

**Scenario:** An engineer used an AI coding assistant to optimize a slow reporting query. The assistant proposed a wide covering index.

**Immediate Result:** The read query became dramatically faster.

**Secondary Result:** The same table handled a high sustained write rate. Index maintenance increased write latency and generated additional WAL/redo and storage pressure. Replication lag increased.

**Resolution:** The index was removed, the reporting workload was redesigned, and schema changes proposed by AI were placed behind a write-load performance gate.

**Engineering Lesson:** A local query improvement can be a system-level regression. AI-generated DDL requires workload-level validation.

## Engineering Notes

1. **Never expose production secrets to an external model:** remove credentials, tokens, PII, and proprietary values before using an external AI service.
2. **Schema context matters:** an LLM without index definitions is being asked to guess.
3. **Plan output is evidence:** SQL text alone does not reveal the chosen physical strategy.
4. **Statistics matter:** provide representative row counts and skew where possible.
5. **Do not optimize for estimated cost alone:** validate actual execution behavior.
6. **One change at a time:** preserve causal attribution using the Module 07 tuning loop.
7. **DDL has blast radius:** index recommendations affect the entire workload, not one query.
8. **Cross-reference:** See Module 02 for EXPLAIN, Module 03 for SARGability, Module 04 for joins, Module 05 for CTE/subquery behavior, Module 07 for the tuning workflow, and `PERFORMANCE_SMELLS.md` for the anti-pattern catalog.

## Interview Insight

**Question:** "How do you use AI tools for SQL tuning without introducing production risk?"

**Answer:** "I use an LLM as an idea generator and syntax translator, never as an authoritative optimizer. I give it the engine version, schema, indexes, workload characteristics, and actual EXPLAIN output. Every proposal is checked against our performance-smell catalog, result equivalence is verified, and the physical plan is benchmarked on representative data. DDL receives an additional write-load test because an index that improves one read query can degrade the entire write workload."
