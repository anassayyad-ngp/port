/* =========================================================================
   MODULE 10: AI-ASSISTED QUERY TUNING LAB
   Objective: Validate an LLM-generated rewrite, detect hallucinations,
              verify result equivalence, and inspect physical plans.
   Engine: PostgreSQL
   ========================================================================= */

-- ==========================================
-- SETUP BLOCK (DDL + DML)
-- ==========================================
DROP TABLE IF EXISTS user_sessions;
DROP TABLE IF EXISTS user_profiles;

CREATE TABLE user_profiles (
    user_id INT PRIMARY KEY,
    region VARCHAR(50) NOT NULL,
    account_tier VARCHAR(20) NOT NULL
);

CREATE TABLE user_sessions (
    session_id BIGSERIAL PRIMARY KEY,
    user_id INT NOT NULL,
    login_time TIMESTAMPTZ NOT NULL,
    duration_sec INT NOT NULL
);

INSERT INTO user_profiles (user_id, region, account_tier)
SELECT
    gs,
    CASE
        WHEN random() > 0.5 THEN 'US'
        ELSE 'EU'
    END,
    CASE
        WHEN random() > 0.8 THEN 'PREMIUM'
        ELSE 'FREE'
    END
FROM generate_series(1, 10000) AS gs;

INSERT INTO user_sessions (
    user_id,
    login_time,
    duration_sec
)
SELECT
    (random() * 9999 + 1)::INT,
    NOW() - (random() * 30 * INTERVAL '1 day'),
    (random() * 3600)::INT
FROM generate_series(1, 500000);

ANALYZE user_profiles;
ANALYZE user_sessions;

-- ==========================================
-- THE "POOR" QUERY (SENT TO AI)
-- ==========================================
/*
 * Objective:
 * Find the average session duration for premium users in the US.
 *
 * Smell:
 * UPPER(region) applies a function to the filtered column.
 *
 * See Module 03 for SARGability.
 */
EXPLAIN (ANALYZE, BUFFERS)
SELECT AVG(s.duration_sec)
FROM user_sessions AS s
JOIN user_profiles AS p
    ON s.user_id = p.user_id
WHERE UPPER(p.region) = 'US'
  AND p.account_tier = 'PREMIUM';

-- ==========================================
-- LLM SUGGESTION (HALLUCINATION CHECK)
-- ==========================================
/*
 * Example unsafe suggestion:
 *
 *   SELECT /*+ INDEX(p idx_profile_opt) *\/ ...
 *
 * Red Flag:
 * PostgreSQL does not use Oracle-style optimizer hints in this form.
 *
 * Another unsafe suggestion:
 *
 *   CREATE INDEX idx_profile_opt
 *   ON user_profiles(user_id)
 *   INCLUDE (region, account_tier);
 *
 * This may be valid DDL, but it is not automatically the correct index.
 * The workload, selectivity, and write cost must be evaluated.
 */

-- ==========================================
-- HUMAN VALIDATION & CORRECTION
-- ==========================================
CREATE INDEX idx_profile_region_tier
    ON user_profiles(region, account_tier, user_id);

ANALYZE user_profiles;

EXPLAIN (ANALYZE, BUFFERS)
SELECT AVG(s.duration_sec)
FROM user_sessions AS s
JOIN user_profiles AS p
    ON s.user_id = p.user_id
WHERE p.region = 'US'
  AND p.account_tier = 'PREMIUM';

-- ==========================================
-- RESULT SET VERIFICATION
-- ==========================================
/*
 * Aggregate equivalence:
 *
 * The result should match because the seeded data stores region as
 * uppercase US/EU. If the source data permitted lowercase/mixed-case
 * values, replacing UPPER(region) with region = 'US' would NOT be
 * automatically equivalent.
 *
 * The test below should return zero rows.
 */
(
    SELECT AVG(s.duration_sec) AS val
    FROM user_sessions AS s
    JOIN user_profiles AS p
        ON s.user_id = p.user_id
    WHERE UPPER(p.region) = 'US'
      AND p.account_tier = 'PREMIUM'
)
EXCEPT
(
    SELECT AVG(s.duration_sec) AS val
    FROM user_sessions AS s
    JOIN user_profiles AS p
        ON s.user_id = p.user_id
    WHERE p.region = 'US'
      AND p.account_tier = 'PREMIUM'
);

-- ==========================================
-- REVERSE EQUIVALENCE CHECK
-- ==========================================
(
    SELECT AVG(s.duration_sec) AS val
    FROM user_sessions AS s
    JOIN user_profiles AS p
        ON s.user_id = p.user_id
    WHERE p.region = 'US'
      AND p.account_tier = 'PREMIUM'
)
EXCEPT
(
    SELECT AVG(s.duration_sec) AS val
    FROM user_sessions AS s
    JOIN user_profiles AS p
        ON s.user_id = p.user_id
    WHERE UPPER(p.region) = 'US'
      AND p.account_tier = 'PREMIUM'
);

-- ==========================================
-- WRITE-AMPLIFICATION EXPERIMENT
-- ==========================================
/*
 * The profile table is small, so the index cost is intentionally not
 * representative of a high-write production table.
 *
 * In production, repeat the same experiment against a realistic table
 * size and write rate before approving AI-generated DDL.
 */
SELECT
    indexrelname,
    idx_scan,
    idx_tup_read,
    idx_tup_fetch
FROM pg_stat_user_indexes
WHERE relname = 'user_profiles'
ORDER BY idx_scan DESC;

-- ==========================================
-- ENGINEERING NOTES & ANALYSIS
-- ==========================================
/*
 * Validation sequence:
 *
 * 1. Identify the smell.
 * 2. Confirm engine/version.
 * 3. Inspect existing indexes.
 * 4. Rewrite only the proven bottleneck.
 * 5. EXPLAIN ANALYZE before/after.
 * 6. Verify result equivalence.
 * 7. Benchmark read workload.
 * 8. Benchmark write workload for new DDL.
 *
 * Cross-reference:
 *   Module 02 -> EXPLAIN
 *   Module 03 -> SARGability
 *   Module 04 -> join strategy
 *   Module 05 -> CTE/subquery behavior
 *   Module 07 -> one-change-at-a-time workflow
 *   PERFORMANCE_SMELLS.md -> anti-pattern catalog
 */
