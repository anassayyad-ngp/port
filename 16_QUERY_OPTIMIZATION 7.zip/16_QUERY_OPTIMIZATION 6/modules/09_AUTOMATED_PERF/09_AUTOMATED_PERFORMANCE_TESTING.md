# Module 09: Automated Performance Testing & CI/CD Integration

## Business Objective
Shift performance tuning left. Prevent query and schema regressions from reaching production by integrating benchmarking, plan inspection, and performance budgets directly into CI/CD.

A query that is "fast enough" on a developer laptop is not evidence of production safety. Data volume, skew, statistics, concurrency, cache state, connection pooling, and plan selection can all change the physical execution path.

## The Performance Budget Concept

Just as frontend engineers enforce bundle-size budgets, database engineers must enforce **latency, plan, and resource budgets**.

- **Latency Budget:** "P95 execution time must not exceed 150 ms."
- **Plan Budget:** "The plan must not introduce a sequential scan on a table above the approved row threshold."
- **Resource Budget:** "Shared reads must remain below 10,000 pages per execution."
- **Throughput Budget:** "TPS must not fall by more than 10% relative to baseline."
- **Cost Budget:** "Bytes processed per dashboard execution must remain below the approved ceiling."

A budget is useful only when it has a machine-readable failure condition.

## Poor Version: The "Localhost Illusion"

```sql
-- Local seed: 1,000 rows
SELECT *
FROM orders
WHERE user_id = 123
  AND status = 'PENDING';
```

**Local EXPLAIN:** Index Scan. Latency: 2 ms.

The developer merges the change.

**Production:** 50M rows, skewed `user_id` distribution, different statistics, concurrent traffic, and a different cache state. The optimizer chooses a substantially more expensive plan and latency rises into seconds.

The local benchmark answered the wrong question because the test environment did not reproduce the cardinality or distribution that drives plan selection.

## Optimized Version: The CI/CD Gate

```yaml
# CI runs against a production-scale or statistically representative
# staging snapshot.
#
# The gate compares:
#   1. latency
#   2. plan shape
#   3. logical/physical reads
#   4. throughput under concurrency
#
# A regression fails the pull request before merge.
```

**Impact:** The regression becomes a review failure rather than a production incident.

## Decision Tree: When to Automate vs. Manual Tuning

```mermaid
graph TD
    A[Query or Schema Change Proposed] --> B{Core API / High-Frequency Query?}
    B -- Yes --> C{Table > 10M Rows or High Skew?}
    C -- Yes --> D[Mandatory Automated Benchmark]
    C -- No --> E[Automated Plan Check + Staging Load Test]
    B -- No --> F{Batch / ETL / Warehouse Job?}
    F -- Yes --> G[Automated SLA + Resource Budget]
    F -- No --> H[Standard PR EXPLAIN Review]
    D --> I{Budget Passed?}
    E --> I
    G --> I
    H --> I
    I -- No --> J[Block Merge + DBA Review]
    I -- Yes --> K[Allow Merge]
```

## Benchmarking Tools

### PostgreSQL: pgbench

Use `pgbench` for controlled concurrency and throughput measurements.

```bash
pgbench -i -s 10 -U test -h localhost perf_db

pgbench \
  -c 10 \
  -j 2 \
  -T 60 \
  -U test \
  -h localhost \
  perf_db
```

`pgbench` is useful for repeatable load, but its default workload is not a substitute for your production query distribution.

### MySQL: sysbench

```bash
sysbench \
  oltp_read_write \
  --mysql-host=127.0.0.1 \
  --mysql-user=test \
  --mysql-password=test \
  --mysql-db=perf_db \
  --threads=16 \
  --time=60 \
  run
```

Use a custom Lua workload when the regression is query-specific. Generic OLTP mixes are useful for system-level pressure tests but may hide a specific query regression.

## CI/CD Integration: GitHub Actions Template

```yaml
# .github/workflows/sql-regression.yml
name: SQL Performance Regression Check

on:
  pull_request:

jobs:
  benchmark:
    runs-on: ubuntu-latest

    services:
      postgres:
        image: postgres:16
        env:
          POSTGRES_USER: test
          POSTGRES_PASSWORD: test
          POSTGRES_DB: perf_db
        ports:
          - 5432:5432
        options: >-
          --health-cmd "pg_isready -U test -d perf_db"
          --health-interval 5s
          --health-timeout 5s
          --health-retries 10

    steps:
      - uses: actions/checkout@v4

      - name: Install PostgreSQL client
        run: |
          sudo apt-get update
          sudo apt-get install -y postgresql-client

      - name: Apply baseline schema
        env:
          PGPASSWORD: test
        run: |
          psql -h localhost -U test -d perf_db \
            -f modules/09_AUTOMATED_PERF/09_AUTOMATED_PERF_LAB.sql

      - name: Capture benchmark baseline
        env:
          PGPASSWORD: test
        run: |
          bash modules/09_AUTOMATED_PERF/run_query_budget.sh \
            baseline

      - name: Apply PR migrations
        env:
          PGPASSWORD: test
        run: |
          if [ -d migrations ]; then
            for file in migrations/*.sql; do
              [ -e "$file" ] || continue
              psql -h localhost -U test -d perf_db -f "$file"
            done
          fi

      - name: Capture post-change benchmark
        env:
          PGPASSWORD: test
        run: |
          bash modules/09_AUTOMATED_PERF/run_query_budget.sh \
            post_change

      - name: Enforce performance budget
        run: |
          bash modules/09_AUTOMATED_PERF/check_performance_budget.sh \
            baseline post_change
```

## CI/CD Integration: GitLab CI Template

```yaml
# .gitlab-ci.yml
stages:
  - benchmark
  - gate

database_benchmark:
  stage: benchmark
  image: postgres:16
  services:
    - name: postgres:16
      alias: postgres
  variables:
    POSTGRES_DB: perf_db
    POSTGRES_USER: test
    POSTGRES_PASSWORD: test
    PGPASSWORD: test
    PGHOST: postgres
  script:
    - apt-get update && apt-get install -y bash jq
    - psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -f modules/09_AUTOMATED_PERF/09_AUTOMATED_PERF_LAB.sql
    - bash modules/09_AUTOMATED_PERF/run_query_budget.sh baseline
    - bash modules/09_AUTOMATED_PERF/run_query_budget.sh post_change
  artifacts:
    paths:
      - baseline.json
      - post_change.json

performance_gate:
  stage: gate
  image: alpine:3.20
  needs:
    - database_benchmark
  script:
    - apk add --no-cache bash jq bc
    - bash modules/09_AUTOMATED_PERF/check_performance_budget.sh baseline post_change
```

## Ready-to-Use Query Budget Script

```bash
#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-baseline}"
OUT="${MODE}.json"

: "${PGHOST:=localhost}"
: "${PGPORT:=5432}"
: "${PGUSER:=test}"
: "${PGDATABASE:=perf_db}"

SQL="
EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)
SELECT order_id, created_at
FROM checkout_orders
WHERE user_id = 12345
  AND status = 'PENDING'
ORDER BY created_at DESC
LIMIT 10;
"

psql -X -q -t -A -c "$SQL" > "$OUT"

echo "Wrote $OUT"
```

## Ready-to-Use Budget Gate

```bash
#!/usr/bin/env bash
set -euo pipefail

BASELINE="${1:?baseline JSON required}"
CURRENT="${2:?current JSON required}"

MAX_REGRESSION_PCT="${MAX_REGRESSION_PCT:-10}"
MAX_EXEC_MS="${MAX_EXEC_MS:-50}"

baseline_ms="$(
  jq -r '.[0]."Execution Time"' "$BASELINE"
)"

current_ms="$(
  jq -r '.[0]."Execution Time"' "$CURRENT"
)"

if [ "$current_ms" = "null" ] || [ "$baseline_ms" = "null" ]; then
  echo "ERROR: unable to extract execution time"
  exit 2
fi

allowed_ms="$(awk -v b="$baseline_ms" -v p="$MAX_REGRESSION_PCT" \
  'BEGIN { printf "%.6f", b * (1 + p / 100) }')"

echo "Baseline: ${baseline_ms} ms"
echo "Current:  ${current_ms} ms"
echo "Allowed:  ${allowed_ms} ms"

if awk -v c="$current_ms" -v a="$allowed_ms" 'BEGIN { exit !(c > a) }'; then
  echo "PERFORMANCE REGRESSION: latency budget exceeded"
  exit 1
fi

if awk -v c="$current_ms" -v m="$MAX_EXEC_MS" 'BEGIN { exit !(c > m) }'; then
  echo "PERFORMANCE REGRESSION: absolute execution budget exceeded"
  exit 1
fi

echo "Performance budget passed."
```

## Plan-Shape Gates

Latency alone is insufficient.

A query can pass a 150-ms budget on a warm CI cache while still introducing a catastrophic plan that will fail at production scale.

Recommended gates include:

```text
SEQ SCAN on large table      -> FAIL / REVIEW
estimated rows >> actual     -> REVIEW
actual rows >> estimated     -> REVIEW
shared read growth > 25%     -> REVIEW
execution time > budget      -> FAIL
TPS regression > 10%         -> FAIL
```

Use plan-shape checks as **risk gates**, not absolute rules. A sequential scan can be correct when the query intentionally consumes a large fraction of a table.

## Production Latency Monitoring

CI catches known changes. Production monitoring catches:

- data distribution changes;
- statistics drift;
- parameter-sensitive plans;
- concurrency effects;
- lock contention;
- cache-state changes;
- workload interactions.

PostgreSQL example:

```sql
SELECT
    queryid,
    calls,
    mean_exec_time,
    total_exec_time,
    rows,
    shared_blks_hit,
    shared_blks_read
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 25;
```

Track both **mean** and **tail latency** where your telemetry supports it. A stable average can hide a damaging P95/P99 regression.

## Real-World Incident: Migration Regression

**Scenario:** A production checkout workload suffered a large latency increase after a schema migration removed an index supporting a high-frequency transaction query.

**Failure Mode:** The migration was validated for correctness but not for execution-plan stability under production-scale data and concurrency.

**Resolution:** The index was restored, the workload was benchmarked under representative concurrency, and schema changes touching core transaction tables were moved behind mandatory performance gates.

**Engineering Lesson:** A migration can be logically correct and operationally unsafe. Performance is part of schema correctness for latency-sensitive systems.

## Engineering Notes

1. **Production-scale data beats production-like row counts:** distribution and skew matter as much as volume.
2. **Benchmark cache state explicitly:** cold and warm cache measurements answer different questions. See `BENCHMARKING_GUIDE.md`.
3. **Run enough iterations:** one before/after result is an observation, not a benchmark.
4. **Use the same database major version:** planner behavior can change across versions.
5. **Pin environment variables:** CPU, memory, parallelism, and connection-pool configuration influence results.
6. **Do not benchmark only throughput:** query-specific regressions can disappear inside an aggregate TPS metric.
7. **Cross-reference:** See Module 02 for plan interpretation, Module 07 for tuning workflow, `PERFORMANCE_SMELLS.md` for review gates, and `BENCHMARKING_GUIDE.md` for measurement discipline.

## Interview Insight

**Question:** "How do you ensure a database migration doesn't degrade performance?"

**Answer:** "I treat performance as a CI gate, not a post-deployment observation. For migrations affecting critical tables, I benchmark against production-scale data and representative concurrency, capture EXPLAIN plans and resource counters, and compare them against a baseline. The merge is blocked when the latency, throughput, buffer-read, or plan-shape budget is violated. I still monitor production because CI cannot reproduce every data-distribution and concurrency condition."
