/* =========================================================================
   MODULE 09: AUTOMATED PERFORMANCE TESTING LAB
   Objective: Create a baseline query, simulate an index regression,
              restore the index, and capture EXPLAIN metrics for CI gating.
   Engine: PostgreSQL
   ========================================================================= */

-- ==========================================
-- SETUP BLOCK (DDL + DML)
-- ==========================================
DROP TABLE IF EXISTS checkout_orders;

CREATE TABLE checkout_orders (
    order_id BIGSERIAL PRIMARY KEY,
    user_id INT NOT NULL,
    status VARCHAR(20) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    payload JSONB
);

INSERT INTO checkout_orders (
    user_id,
    status,
    created_at,
    payload
)
SELECT
    (random() * 50000)::INT,
    CASE
        WHEN random() > 0.8 THEN 'COMPLETED'
        ELSE 'PENDING'
    END,
    NOW() - (random() * 365 * INTERVAL '1 day'),
    '{"items":["item_a","item_b"]}'::JSONB
FROM generate_series(1, 500000);

-- Critical index used by the API query.
CREATE INDEX idx_orders_user_status
    ON checkout_orders(user_id, status, created_at DESC);

ANALYZE checkout_orders;

-- ==========================================
-- BASELINE QUERY
-- ==========================================
/*
 * Core API query:
 * "Fetch recent pending orders for a specific user."
 */
EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)
SELECT
    order_id,
    created_at
FROM checkout_orders
WHERE user_id = 12345
  AND status = 'PENDING'
ORDER BY created_at DESC
LIMIT 10;

-- ==========================================
-- SIMULATE THE "BAD MIGRATION"
-- ==========================================
DROP INDEX IF EXISTS idx_orders_user_status;

ANALYZE checkout_orders;

-- Post-migration plan: expected to require substantially more work.
EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)
SELECT
    order_id,
    created_at
FROM checkout_orders
WHERE user_id = 12345
  AND status = 'PENDING'
ORDER BY created_at DESC
LIMIT 10;

-- ==========================================
-- THE FIX: RESTORE THE PERFORMANCE BUDGET
-- ==========================================
CREATE INDEX idx_orders_user_status
    ON checkout_orders(user_id, status, created_at DESC);

ANALYZE checkout_orders;

EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)
SELECT
    order_id,
    created_at
FROM checkout_orders
WHERE user_id = 12345
  AND status = 'PENDING'
ORDER BY created_at DESC
LIMIT 10;

-- ==========================================
-- RESULT-SET STABILITY CHECK
-- ==========================================
/*
 * Performance changes must not change business semantics.
 * For deterministic comparisons, compare keys rather than relying on
 * floating-point aggregate equality.
 */
WITH before_result AS (
    SELECT
        order_id,
        created_at
    FROM checkout_orders
    WHERE user_id = 12345
      AND status = 'PENDING'
    ORDER BY created_at DESC
    LIMIT 10
),
after_result AS (
    SELECT
        order_id,
        created_at
    FROM checkout_orders
    WHERE user_id = 12345
      AND status = 'PENDING'
    ORDER BY created_at DESC
    LIMIT 10
)
SELECT *
FROM (
    SELECT * FROM before_result
    EXCEPT
    SELECT * FROM after_result
) diff;

-- ==========================================
-- ENGINEERING NOTES & ANALYSIS
-- ==========================================
/*
 * Capture these fields from FORMAT JSON:
 *
 *   Execution Time
 *   Planning Time
 *   Actual Rows
 *   Shared Hit Blocks
 *   Shared Read Blocks
 *
 * CI policy should compare the same metric under the same environment.
 *
 * Example budget:
 *   - absolute execution time <= 50 ms
 *   - regression <= 10%
 *   - shared reads <= approved threshold
 *
 * Cross-reference:
 *   Module 02 -> EXPLAIN
 *   Module 03 -> indexing / SARGability
 *   Module 07 -> tuning workflow
 *   BENCHMARKING_GUIDE.md -> benchmark discipline
 */
