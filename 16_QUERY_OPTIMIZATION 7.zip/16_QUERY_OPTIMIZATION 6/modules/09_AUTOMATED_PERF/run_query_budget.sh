#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-baseline}"
OUT="${MODE}.json"

: "${PGHOST:=localhost}"
: "${PGPORT:=5432}"
: "${PGUSER:=test}"
: "${PGDATABASE:=perf_db}"

SQL="
EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)
SELECT order_id, created_at
FROM checkout_orders
WHERE user_id = 12345
  AND status = 'PENDING'
ORDER BY created_at DESC
LIMIT 10;
"

psql -X -q -t -A -c "$SQL" > "$OUT"

echo "Wrote $OUT"
