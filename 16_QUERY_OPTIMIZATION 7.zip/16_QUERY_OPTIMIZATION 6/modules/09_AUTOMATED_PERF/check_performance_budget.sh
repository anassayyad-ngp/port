#!/usr/bin/env bash
set -euo pipefail

BASELINE="${1:?baseline JSON required}"
CURRENT="${2:?current JSON required}"

MAX_REGRESSION_PCT="${MAX_REGRESSION_PCT:-10}"
MAX_EXEC_MS="${MAX_EXEC_MS:-50}"

baseline_ms="$(
  jq -r '.[0]."Execution Time"' "$BASELINE"
)"

current_ms="$(
  jq -r '.[0]."Execution Time"' "$CURRENT"
)"

if [ "$current_ms" = "null" ] || [ "$baseline_ms" = "null" ]; then
  echo "ERROR: unable to extract execution time"
  exit 2
fi

allowed_ms="$(
  awk -v b="$baseline_ms" -v p="$MAX_REGRESSION_PCT" \
    'BEGIN { printf "%.6f", b * (1 + p / 100) }'
)"

echo "Baseline: ${baseline_ms} ms"
echo "Current:  ${current_ms} ms"
echo "Allowed:  ${allowed_ms} ms"

if awk -v c="$current_ms" -v a="$allowed_ms" 'BEGIN { exit !(c > a) }'; then
  echo "PERFORMANCE REGRESSION: latency budget exceeded"
  exit 1
fi

if awk -v c="$current_ms" -v m="$MAX_EXEC_MS" 'BEGIN { exit !(c > m) }'; then
  echo "PERFORMANCE REGRESSION: absolute execution budget exceeded"
  exit 1
fi

echo "Performance budget passed."
