# Advanced SQL Modules 08–10

These modules extend the SQL Engineering Handbook's query-optimization track:

- `08_CLOUD_COST` — cloud cost optimization and resource governance
- `09_AUTOMATED_PERF` — automated performance testing and CI/CD gates
- `10_AI_TUNING` — safe AI-assisted query tuning with human validation

The modules cross-reference the existing Module 01–07 lessons and the handbook's
`PERFORMANCE_SMELLS.md` and `BENCHMARKING_GUIDE.md` references.
