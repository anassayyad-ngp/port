# Module 08: Cloud Cost Optimization & Resource Governance

## Business Objective
Align query execution plans with cloud billing models. In on-prem environments, a slow query consumes CPU, memory, and I/O. In the cloud (BigQuery, Snowflake, Aurora Serverless), the same physical work becomes a directly measurable operating cost through bytes processed, compute credits, storage, I/O, and concurrency pressure.

Optimization is therefore no longer just about latency; it is about **unit economics**: cost per query, cost per dashboard refresh, cost per API request, and cost per terabyte of useful work.

## The Cost-Aware Optimization Loop

| Engine | Billing / Resource Metric | EXPLAIN / Runtime Proxy | Primary Cost Mitigation |
|---|---|---|---|
| **BigQuery** | Bytes processed / slot consumption | `totalBytesProcessed`, stage input/output, partition pruning | Partition pruning, clustering, projection control, materialized views, result caching |
| **Snowflake** | Warehouse compute credits | Partitions scanned, bytes scanned, spill, warehouse utilization | Micro-partition pruning, clustering, right-sizing, caching, workload isolation |
| **RDS / Aurora PostgreSQL** | IOPS, compute, storage, memory | `Buffers: shared hit/read`, I/O timing, plan rows | SARGable predicates, covering indexes, selective indexes, buffer-pool efficiency |
| **Aurora Serverless** | ACU consumption + I/O | CPU/I/O profile, buffer reads, execution time | Reduce scanned rows/pages, avoid unnecessary indexes, control concurrency |

The engineering question is not:

> "Which query is slow?"

It is:

> "Which physical work is being purchased repeatedly, and can the same result be produced with materially less work?"

## Poor Version: The "Silent Budget Killer"

```sql
-- BigQuery Context: partitioned by event_timestamp
-- The function prevents direct range pruning on the partition key.
SELECT
    user_id,
    COUNT(DISTINCT session_id) AS sessions
FROM analytics.page_views
WHERE EXTRACT(YEAR FROM event_timestamp) = 2025
  AND EXTRACT(MONTH FROM event_timestamp) = 8
GROUP BY user_id;
```

**Cost Impact:** If the table contains 5 TB and the partition predicate cannot be pruned, the engine may process close to the full 5 TB. At a hypothetical $5/TB processing rate, that is approximately $25 per execution. At 100 executions/day for 30 days, the modeled spend is approximately $75,000/month.

The exact bill depends on pricing tier, reservations, caching, editions, region, and workload configuration. The engineering lesson is invariant: **paying for bytes that can be proven irrelevant is avoidable waste.**

## Optimized Version: SARGable Cost Reduction

```sql
SELECT
    user_id,
    COUNT(DISTINCT session_id) AS sessions
FROM analytics.page_views
WHERE event_timestamp >= TIMESTAMP('2025-08-01')
  AND event_timestamp < TIMESTAMP('2025-09-01')
GROUP BY user_id;
```

**Cost Impact:** If only ~160 GB belongs to August, the query processes approximately 160 GB instead of 5 TB. Under the same hypothetical $5/TB model, the modeled processing cost falls to approximately $0.80.

This is the same principle covered in **Module 03: SARGability and Index Usage**: preserve a searchable/range-comparable form of the indexed or partitioned column.

## Cost-Aware Indexing

Indexes are not free optimization.

A read-optimized index can:

- reduce logical reads;
- reduce physical I/O;
- eliminate a sort;
- enable index-only access;
- lower CPU per request.

But it can also:

- increase `INSERT`/`UPDATE` cost;
- increase WAL/redo generation;
- increase storage;
- increase vacuum/maintenance work;
- increase replication traffic;
- reduce cache efficiency by consuming buffer pages.

The correct question is therefore:

```text
Read I/O saved
    >
Write I/O + storage + maintenance + replication cost introduced
```

For a high-write RDS/Aurora table, a wide covering index should be treated as a workload-level change, not a local query fix.

## EXPLAIN & Cost Analysis Discussion

When reviewing an execution plan in a cloud environment, shift attention from **Execution Time** to **Data Volume + Resource Consumption**.

- **BigQuery:** inspect bytes processed, bytes billed, partition pruning, stage input/output, and slot utilization. A query that returns 10 MB may still process terabytes.
- **Snowflake:** inspect partitions scanned versus total partitions, bytes scanned, spills, and warehouse utilization. A high scan ratio is a clustering/pruning signal, but the correct threshold depends on table shape and workload.
- **Aurora/PostgreSQL:** compare `Buffers: shared hit` with `shared read`, plus I/O timing where enabled. High physical reads indicate pressure on storage I/O and buffer residency.
- **All engines:** distinguish one expensive query from a cheap query executed 100,000 times. Workload frequency is part of cost.

### Cost Attribution Model

```text
Query Cost
   │
   ├── Data scanned
   │      ├── partition pruning
   │      ├── projection width
   │      └── join input reduction
   │
   ├── Compute
   │      ├── CPU
   │      ├── hash/sort work
   │      └── concurrency
   │
   ├── Storage / I/O
   │      ├── physical reads
   │      ├── temporary spill
   │      └── index maintenance
   │
   └── Frequency
          ├── dashboard refreshes
          ├── API traffic
          └── scheduled jobs
```

## Budget Governance

Budget alerts should be treated as an engineering control, not an accounting report.

Recommended thresholds:

| Threshold | Engineering Action |
|---|---|
| **50%** | Investigate abnormal spend trajectory |
| **75%** | Identify top workloads and recent plan changes |
| **90%** | Freeze non-essential expensive workloads and remediate |
| **100%** | Escalation / incident path; this is already late |

For production systems, alert on **rate of spend** as well as absolute monthly budget. A query that consumes the entire daily budget in one hour should not wait for the end-of-month threshold.

## Waste Detection Query: BigQuery

```sql
SELECT
    user_email,
    COUNT(*) AS executions,
    SUM(total_bytes_processed) / POW(1024, 4) AS tb_processed,
    SUM(total_bytes_billed) / POW(1024, 4) AS tb_billed,
    SUM(total_slot_ms) / 1000 AS slot_seconds
FROM `region-us`.INFORMATION_SCHEMA.JOBS_BY_PROJECT
WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND job_type = 'QUERY'
  AND state = 'DONE'
GROUP BY user_email
ORDER BY tb_billed DESC
LIMIT 25;
```

Use the query as an **audit starting point**, then attribute cost by normalized query pattern, dashboard, service account, team, and schedule.

## Waste Detection Query: PostgreSQL / Aurora

```sql
SELECT
    queryid,
    calls,
    ROUND(total_exec_time::numeric, 2) AS total_exec_ms,
    ROUND(mean_exec_time::numeric, 2) AS mean_exec_ms,
    shared_blks_hit,
    shared_blks_read,
    ROUND(
        100.0 * shared_blks_read /
        NULLIF(shared_blks_hit + shared_blks_read, 0),
        2
    ) AS physical_read_pct
FROM pg_stat_statements
ORDER BY shared_blks_read DESC
LIMIT 25;
```

The highest-cost workload is not necessarily the query with the highest mean latency. Rank by **aggregate resource consumption** as well as per-call latency.

## Real-World Incident: Partition-Pruning Failure

**Scenario:** A large analytics organization experienced a sustained increase in warehouse spend after a dashboard query was changed from a direct timestamp range to a function applied to the partitioning column.

**Root Cause:** The rewritten predicate prevented effective partition pruning, causing the dashboard to repeatedly scan historical partitions that could have been excluded.

**Resolution:** The predicate was rewritten as a half-open timestamp range, the dashboard query was benchmarked against representative data, and a bytes-processed budget was added to the review checklist.

**Engineering Lesson:** A query can remain within its latency SLA while becoming economically unacceptable. Cost regressions must therefore be monitored independently from latency regressions.

## Engineering Notes

1. **Budget alerts:** alert before the budget is exhausted. A 100% alert is an incident signal, not a prevention mechanism.
2. **Query frequency matters:** a 10-second query run once/day may be cheaper than a 200-ms query run 500,000 times/day.
3. **Projection matters:** avoid `SELECT *` in scan-heavy analytical workloads. See `PERFORMANCE_SMELLS.md`.
4. **Partition pruning must be verified:** do not infer pruning from SQL appearance alone; inspect job statistics.
5. **Materialized views:** use them for repeated, low-volatility aggregations where refresh cost is materially lower than repeated recomputation.
6. **Caching:** result caching can eliminate repeated work, but cache behavior must be understood before using it as the only cost-control mechanism.
7. **Index economics:** calculate the read benefit against write amplification before adding a wide index to a high-throughput table.
8. **Cross-reference:** See Module 02 for EXPLAIN interpretation, Module 03 for SARGability, Module 04 for join fan-out, and Module 07 for the baseline → hypothesis → verification tuning loop.

## Interview Insight

**Question:** "How do you optimize a query when the primary constraint is cloud budget rather than latency?"

**Answer:** "I shift the optimization target from time alone to physical work per execution and workload frequency. For BigQuery I inspect bytes processed and verify partition pruning; for Snowflake I inspect partition pruning, scan volume, spills, and warehouse utilization; for Aurora/PostgreSQL I use buffer and I/O metrics to identify unnecessary reads. I then choose the lowest-cost equivalent plan, validate result equivalence, and benchmark the change under representative workload frequency. For recurring dashboard queries, I also evaluate caching or materialized views rather than repeatedly purchasing the same computation."
