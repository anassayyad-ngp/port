/* =========================================================================
   MODULE 08: CLOUD COST OPTIMIZATION LAB
   Objective: Simulate partition/index pruning and resource reduction.
   Engine: PostgreSQL / Aurora PostgreSQL
   ========================================================================= */

-- ==========================================
-- SETUP BLOCK (DDL + DML)
-- ==========================================
DROP TABLE IF EXISTS cloud_events;

CREATE TABLE cloud_events (
    event_id BIGSERIAL PRIMARY KEY,
    event_timestamp TIMESTAMPTZ NOT NULL,
    user_id INT NOT NULL,
    payload_size INT NOT NULL
);

INSERT INTO cloud_events (event_timestamp, user_id, payload_size)
SELECT
    TIMESTAMPTZ '2025-01-01'
        + (random() * 364.999 * INTERVAL '1 day'),
    (random() * 10000)::INT,
    (random() * 1024)::INT
FROM generate_series(1, 1000000);

CREATE INDEX idx_events_ts_user
    ON cloud_events(event_timestamp, user_id);

ANALYZE cloud_events;

-- ==========================================
-- POOR VERSION (The Budget Killer)
-- ==========================================
/*
 * Why it fails:
 * EXTRACT() must be evaluated against rows before the predicate can
 * determine whether the timestamp belongs to August.
 *
 * On a real partitioned warehouse, a function over the partition key
 * can prevent effective partition pruning. On PostgreSQL, the exact
 * physical plan depends on statistics and indexes; verify with EXPLAIN.
 */
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    user_id,
    COUNT(*) AS events
FROM cloud_events
WHERE EXTRACT(YEAR FROM event_timestamp) = 2025
  AND EXTRACT(MONTH FROM event_timestamp) = 8
GROUP BY user_id;

-- ==========================================
-- OPTIMIZED VERSION (Cost-Aware)
-- ==========================================
/*
 * Why it wins:
 * The timestamp remains bare and is constrained by a half-open range.
 * This gives the B-tree a directly searchable range and is the same
 * SARGability principle covered in Module 03.
 */
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    user_id,
    COUNT(*) AS events
FROM cloud_events
WHERE event_timestamp >= TIMESTAMPTZ '2025-08-01'
  AND event_timestamp <  TIMESTAMPTZ '2025-09-01'
GROUP BY user_id;

-- ==========================================
-- COST / RESOURCE COMPARISON
-- ==========================================
/*
 * Record for both plans:
 *
 * 1. Execution Time
 * 2. shared hit
 * 3. shared read
 * 4. Scan type: Seq Scan vs Index Scan / Bitmap Heap Scan
 * 5. Actual rows
 * 6. Estimated rows
 *
 * Cloud interpretation:
 *
 * PostgreSQL/Aurora:
 *   shared read -> physical storage I/O
 *   shared hit  -> buffer-cache work
 *
 * BigQuery:
 *   equivalent question -> bytes processed / bytes billed
 *
 * Snowflake:
 *   equivalent question -> partitions scanned / bytes scanned
 *
 * The SQL lab is PostgreSQL-compatible; the billing metrics are
 * intentionally mapped conceptually to cloud-native engines.
 */

-- ==========================================
-- OPTIONAL: COVERING INDEX EXPERIMENT
-- ==========================================
/*
 * This index can reduce heap access for some workloads, but it is NOT
 * automatically a win. Measure write amplification before keeping it.
 */
CREATE INDEX idx_events_ts_user_covering
    ON cloud_events(event_timestamp, user_id)
    INCLUDE (payload_size);

EXPLAIN (ANALYZE, BUFFERS)
SELECT
    user_id,
    SUM(payload_size) AS total_payload
FROM cloud_events
WHERE event_timestamp >= TIMESTAMPTZ '2025-08-01'
  AND event_timestamp <  TIMESTAMPTZ '2025-09-01'
GROUP BY user_id;

-- Cleanup for repeated lab execution:
DROP INDEX IF EXISTS idx_events_ts_user_covering;

-- ==========================================
-- ENGINEERING NOTES & ANALYSIS
-- ==========================================
/*
 * Cross-reference:
 *   Module 02 -> EXPLAIN / execution plans
 *   Module 03 -> SARGability and index usage
 *   Module 04 -> join input reduction
 *   Module 07 -> measure -> hypothesis -> change -> verify
 *
 * Do not claim a cloud billing reduction from this PostgreSQL lab alone.
 * The lab proves physical work reduction. The cloud engine's job metrics
 * must be inspected separately to prove billing impact.
 */
