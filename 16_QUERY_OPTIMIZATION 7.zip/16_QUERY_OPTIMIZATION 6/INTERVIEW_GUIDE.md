# Senior SQL Optimization — Interview Guide

25 questions pulled from the concepts across this module, in the format a
senior/staff-level interview actually uses: the question, what a strong
answer covers, the common trap, and a natural follow-up. Work through
these after finishing all lessons and `PRACTICE_PROBLEMS.md` — this guide
assumes the concepts, it doesn't re-teach them.

---

**1. Walk me through what happens when a query executes, from the moment
it's submitted to when rows come back.**
*Strong answer:* the five-stage lifecycle — parsing, binding, optimization,
execution, fetch (Lesson 01) — with clear emphasis on optimization being
where physical execution order is chosen.
*Trap:* describing SQL as executing top-to-bottom as written.
*Follow-up:* "Why doesn't the order you write JOINs in affect execution
order?"

---

**2. What's the difference between EXPLAIN and EXPLAIN ANALYZE?**
*Strong answer:* estimated plan/cost vs. actual execution with real
timing and row counts (Lesson 02).
*Trap:* trusting EXPLAIN estimates for an already-slow query instead of
using ANALYZE.
*Follow-up:* "What does a large gap between estimated and actual rows
tell you?"

---

**3. What does SARGable mean, and give an example of a non-SARGable
predicate.**
*Strong answer:* the indexed column must appear bare — wrapping it in a
function, cast, or expression prevents index use (Lesson 03).
*Trap:* only naming the obvious `YEAR(date_col)` example without
recognizing subtler cases like implicit type conversion.
*Follow-up:* "How would you make `WHERE UPPER(name) = 'X'` SARGable
without changing application logic?"

---

**4. Explain the leftmost-prefix rule for composite indexes.**
*Strong answer:* an index on `(a, b, c)` supports queries filtering on `a`
alone, or `a` and `b`, but not `b` alone efficiently (Lesson 03).
*Trap:* assuming a composite index helps any query touching any of its
columns.
*Follow-up:* "Given `(a, b)`, does a query with `WHERE b = X ORDER BY a`
use it well?"

---

**5. Compare nested loop, hash, and merge joins.**
*Strong answer:* nested loop for small-outer/indexed-inner; hash for two
large unindexed sides; merge for two pre-sorted sides (Lesson 04).
*Trap:* claiming one is "always fastest."
*Follow-up:* "What happens if a hash join's build side doesn't fit in
memory?"

---

**6. Why is NOT IN dangerous with a nullable subquery column?**
*Strong answer:* three-valued logic — if the subquery returns any NULL,
every `NOT IN` comparison evaluates to UNKNOWN, so the query silently
returns zero rows (Lesson 05).
*Trap:* describing this as a performance issue rather than a correctness
bug.
*Follow-up:* "How would you find this bug in an existing codebase?"

---

**7. When would you choose EXISTS over IN?**
*Strong answer:* correctness first (NOT EXISTS avoids the NULL trap),
short-circuit evaluation as a secondary benefit; modern optimizers often
rewrite IN into an equivalent plan anyway (Lesson 05, Lesson 09).
*Trap:* claiming EXISTS is "always faster" without justification.
*Follow-up:* "Does this hold for both IN and NOT IN equally?"

---

**8. Does a CTE always get materialized and computed once?**
*Strong answer:* engine and version dependent — PostgreSQL 12+ inlines
non-recursive, single-reference CTEs by default (Lesson 05).
*Trap:* stating a universal rule without qualifying by engine/version.
*Follow-up:* "How would you force materialization when you specifically
want it?"

---

**9. Name five SQL performance anti-patterns.**
*Strong answer:* any five from Lesson 06 / `PERFORMANCE_SMELLS.md` with a
one-line reason each.
*Trap:* naming patterns without being able to explain *why* each is
costly.
*Follow-up:* "Which of these have you actually seen in production?"

---

**10. Why does a large OFFSET get slower as it grows?**
*Strong answer:* the engine must still generate/count through every
skipped row before returning results — cost scales with offset depth
(Pattern 7, Lesson 09).
*Trap:* assuming an index on the ORDER BY column fixes this — it doesn't
eliminate the skip cost.
*Follow-up:* "Design the keyset pagination alternative."

---

**11. What's the difference between cardinality estimation and
selectivity?**
*Strong answer:* selectivity is the fraction of rows a predicate is
expected to keep; cardinality estimation is the resulting predicted row
count at each plan step, propagated upward (Lesson 08).
*Trap:* conflating the two or being unable to connect them to plan cost.
*Follow-up:* "How does a wrong estimate early in a plan tree affect
decisions made later in the plan?"

---

**12. Explain parameter sniffing.**
*Strong answer:* a cached plan compiled for one parameter's selectivity
gets reused for a very different parameter value, producing "fast for
me, slow for them" symptoms (Lesson 08).
*Trap:* confusing this with stale statistics — related but distinct
causes.
*Follow-up:* "What are two mitigations, and what does each trade off?"

---

**13. When is an optimizer hint the right tool?**
*Strong answer:* after confirming via EXPLAIN that the optimizer's
estimate is wrong for a specific, understood reason a statistics fix
can't address, and the query has a hard SLA (Lesson 08).
*Trap:* reaching for a hint before checking EXPLAIN at all.
*Follow-up:* "What's the maintenance cost of a hint over time?"

---

**14. Why can adding a WHERE condition make a query slower, not faster?**
*Strong answer:* a non-SARGable or low-selectivity added condition can add
evaluation cost without narrowing the result meaningfully, and can even
flip the optimizer's plan choice (see `OPTIMIZER_MYTHS.md`).
*Trap:* asserting WHERE conditions can only help.
*Follow-up:* "Give a concrete example using this handbook's schema."

---

**15. What's a covering index, and how do you recognize one in EXPLAIN
output?**
*Strong answer:* an index containing every column a query needs, avoiding
a table lookup entirely — shown as "Index Only Scan" (Lesson 03).
*Trap:* thinking any index scan is automatically covering.
*Follow-up:* "What's the tradeoff of making an index cover more columns?"

---

**16. Diagnose: EXPLAIN ANALYZE shows estimated rows = 400,000, actual
rows = 3, and most time is in that node. What's your hypothesis?**
*Strong answer:* stale statistics — the optimizer's cost model believed
the filter was far less selective than it actually is (Practice Problem
7, Lesson 07/08).
*Trap:* jumping straight to "add an index" without checking statistics
first.
*Follow-up:* "What's your very next diagnostic step?"

---

**17. Rewrite a correlated subquery that computes per-department max
hire date into something faster.**
*Strong answer:* a window function (`MAX(...) OVER (PARTITION BY ...)`),
Pattern 4/Lesson 09.
*Trap:* not recognizing this as a per-group aggregation problem.
*Follow-up:* "Does every correlated subquery have a window-function
equivalent?"

---

**18. Explain predicate pushdown.**
*Strong answer:* the optimizer applies a WHERE filter before a join
rather than after, shrinking the join's build/probe side, automatically
during the Optimization stage (Lesson 04).
*Trap:* believing you need to manually rewrite the query as a pre-filtered
subquery to achieve this.
*Follow-up:* "When would manual pre-filtering still be necessary?"

---

**19. What's the difference between logical processing order and physical
execution order?**
*Strong answer:* logical order (`FROM → WHERE → GROUP BY → ...`) defines
what the result must be equivalent to; physical order is whatever the
optimizer estimates is cheapest, subject to that equivalence (Lesson 01).
*Trap:* believing they're the same thing.
*Follow-up:* "Give an example where they clearly diverge."

---

**20. Your query is fast in staging and slow in production with identical
code. What do you check?**
*Strong answer:* data volume/distribution differences, statistics
freshness, and possibly parameter sniffing — not a code regression
(Lesson 07's workflow, Lesson 08).
*Trap:* assuming the code must have silently changed.
*Follow-up:* "How would you get production-representative data into
staging safely?"

---

**21. Explain the tradeoff of adding an index.**
*Strong answer:* faster reads for queries it serves, slower writes for
every INSERT/UPDATE/DELETE touching its columns, plus storage cost
(Lesson 03).
*Trap:* treating indexing as a strictly positive action with no cost.
*Follow-up:* "How would you decide whether an existing index is worth
keeping?"

---

**22. What causes a hash join to spill to disk, and what does that look
like in EXPLAIN ANALYZE?**
*Strong answer:* the build side exceeds available working memory; shows
up as a large jump between estimated and actual time/cost (Lesson 04's
Edge Cases).
*Trap:* not connecting memory limits to join algorithm behavior at all.
*Follow-up:* "What are two ways to address it?"

---

**23. Why might an "obviously equivalent" query rewrite actually change
results?**
*Strong answer:* UNION vs. UNION ALL semantics, DISTINCT masking a join
you still need columns from, or NULL-handling differences (see "When
These Patterns Don't Apply," Lesson 09).
*Trap:* assuming syntactic rewrites are always result-safe.
*Follow-up:* "Walk through a specific example where this bit you or a
team you know of."

---

**24. What's the risk of relying on EXPLAIN's cost numbers to compare two
completely different queries?**
*Strong answer:* cost is unitless and relative, meaningful only for
comparing plans of the *same* query against each other, not across
different queries (`OPTIMIZER_MYTHS.md`).
*Trap:* citing a lower "cost" number as proof one query is faster than an
unrelated one.
*Follow-up:* "What would you use instead to compare two different
queries' real-world cost?"

---

**25. Design a benchmarking methodology to validate that an index change
actually helped.**
*Strong answer:* cold/warm cache separation, 10+ iterations, average +
median + variance, buffers/logical reads alongside wall-clock time,
interleaved before/after runs (see `BENCHMARKING_GUIDE.md`).
*Trap:* "I ran it once before and once after and compared the numbers."
*Follow-up:* "What would make you distrust your own benchmark result?"

---

## How to Use This Guide

Don't memorize the "strong answer" text verbatim — if you can only recite
it, a follow-up question will expose that immediately. Work through the
corresponding lesson and `PRACTICE_PROBLEMS.md` items until you can
generate the explanation from understanding, not recall.
