# Benchmarking Guide

## Introduction

"I ran it once and it was faster" is not a benchmark — it's an anecdote.
This guide covers how to measure query performance changes rigorously
enough to trust the result, and the specific traps that make one-shot
measurements misleading.

## Why Benchmarking Discipline Matters

Query execution time is noisy: cache state, concurrent load, disk
contention, and even which specific rows a query happens to touch can
shift timing run to run. A change that looks like a 30% improvement from a
single before/after run can easily be noise — or worse, a real regression
masked by a lucky run. Query tuning claims that reach production decisions
(index changes, query rewrites shipped to a whole team) deserve more rigor
than "felt faster when I tried it."

## Cold Cache vs. Warm Cache

- **Cold cache**: the data your query needs is not in memory (buffer
  pool/page cache) — the engine must read from disk. This is the
  worst-case, first-request scenario.
- **Warm cache**: the data is already in memory from a recent prior
  access — subsequent identical or overlapping queries run dramatically
  faster purely from cache locality, independent of any query change.

**Always benchmark both, and always report which one you measured.** A
query tuning change that only helps once data is already warm may not
help the first request of the day, and a change that helps cold-cache
performance may look unimpressive on an already-warm benchmark. Comparing
a cold-cache "before" against a warm-cache "after" (e.g., because the
"before" was run first in a session with an empty cache) produces a false
improvement that has nothing to do with the actual query change.

```sql
-- PostgreSQL: force a cache-state observation
EXPLAIN (ANALYZE, BUFFERS) SELECT ...;
-- "Buffers: shared hit=X read=Y" — hit = from cache, read = from disk
```

## What to Measure

| Metric | What it tells you |
|---|---|
| Execution Time | Wall-clock time to run the query (what users actually feel) |
| Planning Time | Time spent choosing a plan — usually small, but matters for very short, very frequent queries |
| Rows | Actual vs. estimated rows processed at each plan step |
| Buffers / Logical Reads | Pages accessed from cache — proportional to work done, independent of disk speed |
| Physical Reads | Pages actually read from disk — the real cost of a cold cache |

Execution time alone tells you *whether* something changed. Buffers/reads
tell you *why* — a query that got faster with unchanged buffer counts
probably benefited from a warmer cache, not from doing less work.

## Benchmark Methodology

**Never benchmark once.** A single run captures one noisy sample, not a
performance characteristic. Minimum discipline:

1. Run the query **10+ times** in the target cache state (cold or warm,
   consistently)
2. Discard the first run if you're specifically measuring warm-cache
   performance (it primes the cache)
3. Record **average and median** — if they diverge significantly, that's
   itself a signal of high variance worth investigating
4. Record **variance/standard deviation**, not just the average — a change
   that reduces average time but increases variance may be a worse
   production experience (unpredictable latency), even if it's "faster on
   average"
5. Benchmark the **before** and **after** versions in the *same*
   environment, ideally interleaved (before, after, before, after) rather
   than all-before-then-all-after, to average out any environmental drift
   during the benchmark session

## How NOT to Benchmark

- Running each version once and comparing single numbers
- Comparing a cold-cache run against a warm-cache run without labeling
  which is which
- Benchmarking on a laptop/dev machine with a tiny fraction of production
  data volume and generalizing the result to production scale
- Benchmarking against production during peak traffic, where contention
  from other queries dominates the signal
- Ignoring planning time for queries that run extremely frequently at low
  per-call cost — at high QPS, planning overhead can matter as much as
  execution time

## Production Benchmarking Checklist

- [ ] Benchmarked against a data volume representative of production, not
      a small dev sample
- [ ] Measured both cold and warm cache scenarios, labeled clearly
- [ ] Ran 10+ iterations per version, recorded average, median, and
      variance
- [ ] Compared buffers/logical reads, not just wall-clock time
- [ ] Benchmarked before/after in an interleaved order, same environment
- [ ] Verified the rewritten query produces identical results to the
      original (see Lesson 09's "when patterns don't apply")
- [ ] Documented the benchmark methodology alongside the result, so a
      future reader can trust (or challenge) the claimed improvement

## Further Reading

- PostgreSQL documentation: `EXPLAIN (ANALYZE, BUFFERS)` usage
- See also: Lesson 07 (Query Tuning Workflow) for how benchmarking fits
  into the broader measure → hypothesize → change → verify loop
