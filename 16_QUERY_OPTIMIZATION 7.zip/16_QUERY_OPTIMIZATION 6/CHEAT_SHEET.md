# Query Optimization Cheat Sheet

*One page. Print it, pin it, reference it during code review.*

## The Tuning Loop

```
Measure → Read the Plan → Hypothesize → Change ONE Thing → Verify
```
Never guess. Never stack unproven changes. (Lesson 07)

## SARGability Check

Is the indexed column **bare**, alone, on one side of the comparison?
- ❌ `WHERE YEAR(hire_date) = 2023`
- ✅ `WHERE hire_date >= '2023-01-01' AND hire_date < '2024-01-01'`

## Join Algorithm Quick-Pick

| Shape | Likely algorithm |
|---|---|
| Small outer + indexed inner | Nested Loop |
| Two large, unindexed sides | Hash Join |
| Both sides pre-sorted/indexed | Merge Join |

## Rewrite Patterns (before → after)

| Before | After | Why |
|---|---|---|
| `OR` across columns | `UNION ALL` | each half uses its own index |
| `DISTINCT` after a join | `EXISTS` | no fan-out to deduplicate |
| `IN (subquery)` | `EXISTS` | short-circuits; safer with NULLs |
| `NOT IN (subquery)` | `NOT EXISTS` | avoids the NULL correctness trap |
| correlated subquery (per-group) | window function | single pass, not per-row |
| `SELECT *` | explicit columns | enables covering indexes |
| `LIKE '%text'` | `LIKE 'text%'` | leading wildcard defeats B-tree index |
| large `OFFSET` | keyset pagination | flat cost regardless of page depth |

## Pre-Deployment Checklist

- [ ] Statistics current (`ANALYZE` / `UPDATE STATISTICS` run recently)
- [ ] Every WHERE/JOIN predicate checked for SARGability
- [ ] Composite index column order matches actual query filters
- [ ] Join algorithm sanity-checked against table sizes
- [ ] `NOT EXISTS` used instead of `NOT IN` on nullable columns
- [ ] No unindexed correlated subqueries doing per-group work
- [ ] No `SELECT *` in production paths
- [ ] Pagination uses keyset, not large `OFFSET`
- [ ] Benchmarked cold AND warm cache, 10+ runs, not a single sample
- [ ] Change validated with `EXPLAIN ANALYZE` before/after, not assumed

## Diagnosing "It's Slow"

```
Slow query
  ├─ EXPLAIN ANALYZE first
  ├─ Estimated rows ≈ actual rows?
  │    NO  → stale statistics → ANALYZE / UPDATE STATISTICS
  │    YES → continue
  ├─ Seq Scan on a large, filtered table?
  │    YES → missing index OR non-SARGable predicate
  ├─ Nested Loop with no index on inner side?
  │    YES → missing join-column index
  ├─ Sort before ORDER BY/LIMIT?
  │    YES → missing index matching sort order
  └─ Correlated subquery node, high cost?
       YES → rewrite as JOIN / EXISTS / window function
```

## Three Myths Worth Remembering

- EXPLAIN "cost" ≠ milliseconds — it's relative and unitless
- More indexes ≠ always faster — every index taxes every write
- `LIMIT` doesn't fix a slow query — it can still process everything first

## Further Depth

Full reasoning behind every row above: `README.md` → lesson index.
Rewrite patterns in full: `09_QUERY_REWRITE_PATTERNS.md`.
Myths explained: `OPTIMIZER_MYTHS.md`. Smells catalog: `PERFORMANCE_SMELLS.md`.
