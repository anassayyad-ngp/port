# Optimizer Myths

Common beliefs about query optimizers that are wrong, partially wrong, or
true-only-sometimes. Each one has caused real production mistakes.

---

### ❌ "More indexes = faster"

Every index speeds up specific reads and slows down every write that
touches its columns. A table with fifteen overlapping indexes isn't
"maximally optimized" — it's paying write overhead for indexes that may
never be chosen by the optimizer, or that duplicate coverage another index
already provides. Audit actual index usage before adding more (see
Lesson 03's engineering notes).

### ❌ "EXPLAIN cost equals execution time"

`EXPLAIN`'s cost numbers are unitless, relative, internal-planner values —
not milliseconds, not any real-world unit. They're useful for comparing
two plans for the *same* query against each other; they are not directly
comparable across different queries, and they're an *estimate*, not a
measurement. Use `EXPLAIN ANALYZE`'s actual timing for real numbers
(Lesson 02).

### ❌ "CTEs are always slower than subqueries"

True only for engines/versions that always materialize CTEs as an
optimization fence (old PostgreSQL versions pre-12). Modern PostgreSQL,
SQL Server, and MySQL 8+ generally inline non-recursive CTEs identically
to an equivalent subquery — verify against your actual engine and version
before assuming either direction (Lesson 05).

### ❌ "JOIN is always slower than a subquery" (or vice versa)

Neither is universally true. A cost-based optimizer typically transforms
many subquery forms into semi-join plans equivalent to a JOIN anyway. The
actual cost depends on table sizes, available indexes, and selectivity —
not on which syntax you happened to choose (Lesson 04, Lesson 08).

### ❌ "DISTINCT is free / a safe way to clean up results"

`DISTINCT` requires a real sort or hash-based deduplication pass over the
full result set — it has a cost proportional to result size. It's also
frequently masking an unintended join fan-out rather than solving a real
problem (Pattern 2, Lesson 09).

### ❌ "LIMIT fixes a slow query"

`LIMIT` reduces how many rows are *returned*, not necessarily how many
rows are *processed* to produce them. A `LIMIT 10` on a query with no
supporting index for its `ORDER BY` can still require a full sort of the
entire result set before the first 10 rows can be selected. `LIMIT`
without `ORDER BY` also doesn't guarantee *which* rows you get — different
calls can return different rows.

### ❌ "A clustered/primary key index is always the fastest access path"

It's the fastest path *for queries that filter or sort by that key*. A
query filtering on a completely different column gains nothing from the
primary key index and needs its own supporting index — "the table has an
index" is not the same claim as "this query's filter is indexed."

### ❌ "The optimizer always finds the best possible plan"

Cost-based optimization is a heuristic search over an enormous space, not
an exhaustive proof of optimality — especially for many-table joins, where
most engines fall back to heuristics past a join-count threshold rather
than evaluating every possible order (Lesson 04's Edge Cases). "The
optimizer chose it" means "estimated cheapest among plans it considered,"
not "provably optimal."

### ❌ "Adding `WHERE` conditions can only make a query faster"

Only if the added condition is SARGable and selective. A condition that
wraps a column in a function, or that has very low selectivity, can add
evaluation cost without meaningfully narrowing the result — and can even
change which plan the optimizer picks, sometimes for the worse if
statistics are misleading.

---

## Why These Myths Persist

Most of these were true, or close to true, on some specific engine and
version at some point — and then got repeated as universal folklore long
after the engine changed. The actual antidote to all of them is the same:
**check `EXPLAIN` on your specific engine and data**, per the workflow in
Lesson 07, rather than trusting a rule you can't verify.
