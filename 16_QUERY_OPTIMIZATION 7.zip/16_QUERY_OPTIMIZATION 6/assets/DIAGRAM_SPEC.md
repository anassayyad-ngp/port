# Module 16 — Diagram Specifications

These are text specifications for the SVG diagrams referenced conceptually
throughout Module 16. Written so a designer/contributor can produce
consistent, on-brand SVGs later without needing to re-derive the content —
matching the handbook's existing SVG-based engineering diagram style.

---

### 1. `sql-execution-pipeline.svg`
**Purpose:** Visualize the five-stage query execution lifecycle (Lesson 01).
**Layout:** Horizontal pipeline, 5 boxes left to right: Parsing → Binding →
Optimization → Execution → Fetch, connected by arrows.
**Labels:** One-line description under each box (e.g., "Optimization —
cost-based plan selection").
**Suggested dimensions:** 900×220px.

### 2. `execution-plan-tree.svg`
**Purpose:** Show how to read a plan bottom-up (Lesson 02).
**Layout:** Inverted tree, root node at top (e.g. "Sort"), branching down
through "HashAggregate" → "Hash Join" → two children ("Seq Scan", "Index
Scan"). Annotate the most expensive node with a highlight color.
**Labels:** Node name + cost estimate placeholder on each box.
**Suggested dimensions:** 800×600px.

### 3. `sargable-vs-non-sargable.svg`
**Purpose:** Side-by-side comparison (Lesson 03).
**Layout:** Two columns. Left: "Non-SARGable" with a red/warning accent,
showing `YEAR(hire_date) = 2023` with the function circled. Right:
"SARGable" with a green/success accent, showing the bare-column range
rewrite.
**Suggested dimensions:** 800×400px.

### 4. `covering-index.svg`
**Purpose:** Illustrate index-only scan (Lesson 03).
**Layout:** Two panels — "Without covering index" (index → table lookup
arrow) vs. "With covering index" (index only, no table arrow, marked
"Index Only Scan").
**Suggested dimensions:** 800×350px.

### 5. `nested-loop-vs-hash-vs-merge.svg`
**Purpose:** Compare the three join algorithms side by side (Lesson 04).
**Layout:** Three columns, one per algorithm, each with a small annotated
diagram: Nested Loop (looping arrows between two tables), Hash Join (build
table → hash table → probe), Merge Join (two sorted lists zipping
together).
**Suggested dimensions:** 1000×420px.

### 6. `predicate-pushdown.svg`
**Purpose:** Show a WHERE filter moving from "after join" to "before join"
position (Lesson 04).
**Layout:** Before/after query-tree comparison — same shape as the
execution-plan-tree spec, but showing the filter node's position shift.
**Suggested dimensions:** 800×500px.

### 7. `query-tuning-workflow.svg`
**Purpose:** The five-step circular workflow (Lesson 07).
**Layout:** Circular/cyclical diagram, five nodes: Measure → Read the Plan
→ Form a Hypothesis → Change One Thing → Verify Impact → (arrow back to
Measure).
**Suggested dimensions:** 700×700px (square, to support the circular
layout).

### 8. `optimization-checklist.svg`
**Purpose:** Quick-reference checklist graphic summarizing the module.
**Layout:** Vertical checklist styled consistent with the module completion
checklist in README.md.
**Suggested dimensions:** 600×800px.

---

## Style Requirements (match existing handbook diagrams)

- Consistent SVG-based engineering style (no photographic imagery, no
  clipart)
- Color-neutral base palette with one accent color reserved for
  "expensive/warning" callouts
- Every diagram must include: purpose (as alt text/title), clear labels on
  every node, and explicit relationships (arrows, not implied proximity)
