# Performance Smells — Quick Reference

A "code smell" for SQL: not necessarily wrong, but a strong signal that
something is worth a second look. Skim this before a code review or when
triaging a slow-query report — most real incidents trace back to one of
these.

| Smell | Why it's a smell | Detect it | Fix |
|---|---|---|---|
| `SELECT *` | Pulls unneeded columns, defeats covering indexes, breaks silently on schema change | grep for `SELECT \*` in query logs/codebase | Explicit column projection (Pattern 5, Lesson 09) |
| `LIKE '%text'` | Leading wildcard can't use a standard B-tree index | grep for `LIKE '%` in WHERE clauses | Prefix search, or trigram/full-text index (Pattern 6) |
| Function wrapping a WHERE column | Non-SARGable — forces per-row evaluation | Look for `WHERE FUNC(column) = ...` | Rewrite so the column is bare (Lesson 03, Pattern 8) |
| `OR` across unrelated columns | Defeats single-index usage | Look for `WHERE a = X OR b = Y` on different columns | `UNION ALL` split (Pattern 1) |
| `DISTINCT` used reflexively | Often masks an unintended join fan-out | `SELECT DISTINCT` appearing right after a JOIN | Fix the join, or use `EXISTS` (Pattern 2) |
| Unnecessary `ORDER BY` | Sort cost paid for output nobody consumes in that order | `ORDER BY` on a query only used for `COUNT`/`EXISTS` checks | Remove it |
| Subquery re-run per row (correlated) | Can force per-outer-row re-evaluation | Subquery referencing an outer alias inside `SELECT`/`WHERE` | Window function or JOIN (Pattern 4) |
| N+1 query pattern | One query per parent row instead of a batched query | Repeated near-identical queries in app logs/APM in a tight loop | Batch with `IN (...)` or a JOIN |
| Implicit type conversion | Can silently defeat an index on the converted side | Comparing `INT` column to string literal, or similar mismatches | Match literal type to column type exactly |
| Large `OFFSET` pagination | Cost grows with offset depth regardless of indexing | `LIMIT n OFFSET` with large/growing offset values | Keyset/cursor pagination (Pattern 7) |
| Unbounded/huge `IN (...)` list | Some engines handle very large IN lists poorly (parse time, plan time) | `IN (` followed by hundreds/thousands of literal values | Temp table + JOIN, or array/VALUES-based semi-join |
| Missing join condition | Accidental cartesian product | Comma-join syntax, or a JOIN with no/wrong ON clause | Explicit, correct JOIN...ON |
| `NOT IN` with a nullable subquery | Silently returns zero rows if any NULL is present | `NOT IN (SELECT ... )` where the subquery column can be NULL | `NOT EXISTS` (Pattern 3) |
| "Magic number" `LIMIT` used as a performance patch | Masks an underlying scan/sort cost rather than fixing it | `LIMIT` added to a slow query with no `ORDER BY` guaranteeing which rows you get | Fix the actual bottleneck; `LIMIT` alone doesn't guarantee which rows are cheap to produce |

## How to Use This List

Treat it as a first pass, not a verdict — every smell here has legitimate
uses (a small, genuinely bounded `IN` list is fine; `SELECT *` in a
throwaway analysis query is fine). The list exists to make you *pause and
check*, not to make you rewrite on sight.

See [`06_COMMON_PERFORMANCE_ANTI_PATTERNS.md`](./06_COMMON_PERFORMANCE_ANTI_PATTERNS.md)
and [`09_QUERY_REWRITE_PATTERNS.md`](./09_QUERY_REWRITE_PATTERNS.md) for the
full explanations and runnable rewrites behind each row above.
