# Module 16 — Query Optimization

![Module 16 Banner](./assets/images/hero.svg)

`Difficulty: Advanced` · `Est. Time: 10–14 hrs` · `Prerequisites: Modules 01–14` · `License: MIT`

## Introduction

Every module before this one taught you how to get a *correct* answer out of SQL.
This module teaches you how to get a *fast* one — and, more importantly, how to
reason about *why* a query is slow before you touch it.

Query optimization is the point where SQL stops being a language you write and
becomes a system you reason about. The same `SELECT` can execute in 2 milliseconds
or 20 seconds depending on indexes, statistics, join order, and how the query is
shaped — and the engine, not the syntax, decides which one you get.

## Why Query Optimization Matters

In production, a slow query is never just a slow query. It is:

- A dashboard that times out for an executive during a board meeting
- A payment reconciliation job that misses its nightly SLA
- A fraud-detection query that can't keep up with transaction volume
- A support ticket queue that grows because the "find open tickets" query scans
  the whole table on every page load

Data analysts and analytics engineers who can only *write* correct SQL hit a
ceiling. The ones who get pulled into architecture conversations are the ones
who can also explain *why* a query is slow and *how* to fix it — in language
a backend engineer or DBA respects.

## Learning Objectives

By the end of this module, you will be able to:

- Trace a query through its full execution lifecycle, from parsing to result set
- Read `EXPLAIN` / `EXPLAIN ANALYZE` output and distinguish estimated cost from
  actual cost
- Determine whether a predicate is **SARGable** and rewrite non-SARGable
  predicates so indexes can be used
- Recognize when a query will use an index versus force a full table scan
- Compare nested loop, hash, and merge join strategies and predict which one
  the optimizer will pick and why
- Rewrite `IN`, `EXISTS`, and correlated subqueries into the fastest equivalent
  for a given scenario
- Identify the most common production performance anti-patterns before they
  ship
- Follow a repeatable, professional query-tuning workflow instead of guessing
- Explain how the cost-based optimizer estimates cardinality and why bad
  estimates produce bad plans
- Apply eight standard query rewrite patterns and explain the reasoning
  behind each, not just the syntax

## Engineering Mindset

Treat every slow query as a diagnosis problem, not a rewriting problem.
The instinct to "just add an index" or "just rewrite the subquery" without
first reading the execution plan is how production databases end up with
40 redundant indexes and queries that are still slow. The workflow in this
module is always: **measure → read the plan → form a hypothesis → change one
thing → measure again.**

## Business Motivation

This module continues using the handbook's shared `employes` /
`departments` / `locations` schema (see [`00_Schema`](../00_Schema)) — but
every lesson frames it at **production scale**. A 3-table HR schema with a
few dozen rows behaves identically whether it's indexed or not; the same
schema with 50 million `employes` rows across a multinational company does
not. Each lesson explicitly states the scenario's assumed production size,
because SARGability, index selection, and join strategy only matter once
data volume makes the optimizer's decisions visible.

## Industry Use Cases

The techniques in this module apply directly across industries — this is
where "query optimization" stops being an abstract skill and becomes a
line item on an incident report:

| Industry | Where this module's techniques show up |
|---|---|
| Banking / Finance | Fraud-detection queries that must keep pace with transaction volume; reconciliation jobs with nightly SLAs |
| Healthcare | Compliance reporting queries against large patient/claims tables under strict runtime windows |
| Retail / E-commerce | Product search and dashboard queries under peak-traffic load (sales events, holidays) |
| SaaS | Multi-tenant queries where a single tenant's data skew can silently degrade a shared query plan |
| Insurance | Actuarial and claims-history aggregation queries against multi-year historical tables |
| Logistics / Supply Chain | Real-time inventory and routing queries where OFFSET-based pagination anti-patterns are common |
| HR / Workforce Analytics | The exact schema this module uses — staffing, compliance, and onboarding reports at company scale |

## Diagram Gallery

All diagrams referenced throughout this module's lessons, in one place:

| Diagram | Used in |
|---|---|
| [`sql-execution-pipeline.svg`](./assets/diagrams/sql-execution-pipeline.svg) | Lesson 01 |
| [`execution-plan-tree.svg`](./assets/diagrams/execution-plan-tree.svg) | Lesson 02 |
| [`sargable-vs-non-sargable.svg`](./assets/diagrams/sargable-vs-non-sargable.svg) | Lesson 03 |
| [`covering-index.svg`](./assets/diagrams/covering-index.svg) | Lesson 03 |
| [`nested-loop-vs-hash-vs-merge.svg`](./assets/diagrams/nested-loop-vs-hash-vs-merge.svg) | Lesson 04 |
| [`predicate-pushdown.svg`](./assets/diagrams/predicate-pushdown.svg) | Lesson 04 |
| [`query-tuning-workflow.svg`](./assets/diagrams/query-tuning-workflow.svg) | Lesson 07 |
| [`optimization-decision-tree.svg`](./assets/diagrams/optimization-decision-tree.svg) | Reference — "where do I even start" |
| [`troubleshooting-index-ignored.svg`](./assets/diagrams/troubleshooting-index-ignored.svg) | Reference — diagnosing an ignored index |
| [`optimization-checklist.svg`](./assets/diagrams/optimization-checklist.svg) | Reference / this README |

See [`assets/DIAGRAM_SPEC.md`](./assets/DIAGRAM_SPEC.md) for each diagram's
design specification.

## Reference Guides

Beyond the seven core lessons, this module includes standalone reference
material meant for quick lookup during code review or live incident
triage — not sequential reading:

| Guide | What it's for |
|---|---|
| [`08_COST_BASED_OPTIMIZER.md`](./08_COST_BASED_OPTIMIZER.md) | Statistics, histograms, cardinality estimation, parameter sniffing — the layer underneath every plan choice |
| [`09_QUERY_REWRITE_PATTERNS.md`](./09_QUERY_REWRITE_PATTERNS.md) | Eight before/after rewrite patterns with the reasoning behind each |
| [`PERFORMANCE_SMELLS.md`](./PERFORMANCE_SMELLS.md) | One-page table of red flags to scan for in code review |
| [`OPTIMIZER_MYTHS.md`](./OPTIMIZER_MYTHS.md) | Common false beliefs about optimizers, and why they're wrong |
| [`BENCHMARKING_GUIDE.md`](./BENCHMARKING_GUIDE.md) | How to measure a performance change rigorously enough to trust it |
| [`CHEAT_SHEET.md`](./CHEAT_SHEET.md) | One-page printable summary of the whole module |
| [`INTERVIEW_GUIDE.md`](./INTERVIEW_GUIDE.md) | 25 senior-level questions with traps and follow-ups |

## Prerequisites

This module assumes you're comfortable with everything through
[`14_VIEWS`](../14_VIEWS) — particularly joins, subqueries, CTEs, and window
functions, since optimization techniques are demonstrated against those
constructs rather than re-teaching them.

> **A note on sequencing:** the original curriculum roadmap places an
> `15_INDEXES` module before this one. That module hasn't been written yet in
> this repository, so this module includes a self-contained indexing primer
> (Lesson 03) covering exactly what's needed for SARGability and index-usage
> reasoning. A dedicated, deeper Indexes module (B-tree internals, clustered
> vs. non-clustered structures, index maintenance) is tracked as a follow-up
> in the [ROADMAP](../ROADMAP.md).

## Folder Structure

```text
16_QUERY_OPTIMIZATION/
├── README.md
├── CONTRIBUTING.md          -- module-specific contribution conventions
├── CHEAT_SHEET.md           -- one-page printable summary
├── PERFORMANCE_SMELLS.md    -- code-review quick reference
├── OPTIMIZER_MYTHS.md       -- common false beliefs, debunked
├── BENCHMARKING_GUIDE.md    -- rigorous performance measurement
├── INTERVIEW_GUIDE.md       -- 25 senior-level Q&A
├── 01_QUERY_EXECUTION_LIFECYCLE.md
├── 01_QUERY_EXECUTION_LIFECYCLE.sql
├── 02_EXPLAIN_AND_EXECUTION_PLANS.md
├── 02_EXPLAIN_AND_EXECUTION_PLANS.sql
├── 03_SARGABILITY_AND_INDEX_USAGE.md
├── 03_SARGABILITY_AND_INDEX_USAGE.sql
├── 04_JOIN_OPTIMIZATION.md
├── 04_JOIN_OPTIMIZATION.sql
├── 05_SUBQUERY_AND_CTE_OPTIMIZATION.md
├── 05_SUBQUERY_AND_CTE_OPTIMIZATION.sql
├── 06_COMMON_PERFORMANCE_ANTI_PATTERNS.md
├── 06_COMMON_PERFORMANCE_ANTI_PATTERNS.sql
├── 07_QUERY_TUNING_WORKFLOW.md
├── 08_COST_BASED_OPTIMIZER.md
├── 08_COST_BASED_OPTIMIZER.sql
├── 09_QUERY_REWRITE_PATTERNS.md
├── 09_QUERY_REWRITE_PATTERNS.sql
├── PRACTICE_PROBLEMS.md
├── SOLUTIONS.sql
└── assets/
    ├── DIAGRAM_SPEC.md      -- design specifications for every diagram
    ├── images/
    │   └── hero.svg         -- module banner
    └── diagrams/
        ├── sql-execution-pipeline.svg
        ├── execution-plan-tree.svg
        ├── sargable-vs-non-sargable.svg
        ├── covering-index.svg
        ├── nested-loop-vs-hash-vs-merge.svg
        ├── predicate-pushdown.svg
        ├── query-tuning-workflow.svg
        ├── optimization-decision-tree.svg
        ├── troubleshooting-index-ignored.svg
        └── optimization-checklist.svg
```

## Learning Flow

Work through the lessons in order — each one assumes the previous:

| # | Lesson | Core Question |
|---|--------|----------------|
| 01 | Query Execution Lifecycle | What actually happens between you hitting "run" and getting rows back? |
| 02 | EXPLAIN & Execution Plans | How do I ask the engine to show its work? |
| 03 | SARGability & Index Usage | Why does the exact same logical filter sometimes use an index and sometimes not? |
| 04 | Join Optimization | How does the optimizer decide *how* to join, not just *what* to join? |
| 05 | Subquery & CTE Optimization | When does `EXISTS` beat `IN`, and when does a CTE hurt instead of help? |
| 06 | Anti-Patterns | What are the recurring mistakes that quietly wreck performance? |
| 07 | Query Tuning Workflow | How do I put all of this together into a repeatable process? |
| 08 | Cost-Based Optimizer | Where do the optimizer's cost numbers actually come from? |
| 09 | Query Rewrite Patterns | What's the fast reference for "bad shape → better shape," and why does each one work? |

## SQL Processing Order (recap, for optimization context)

```text
FROM  →  JOIN  →  WHERE  →  GROUP BY  →  HAVING  →  SELECT  →  DISTINCT  →  ORDER BY  →  LIMIT
```

The optimizer does **not** execute in this order — it executes in whatever
order it estimates will be cheapest, subject to producing a result identical
to this logical order. That gap between *logical* order and *physical
execution* order is the entire subject of this module.

## Dialect Coverage

Examples are written in ANSI-standard SQL first, with dialect-specific notes
called out wherever `EXPLAIN` syntax or optimizer behavior diverges — since
optimization is the module where dialect differences matter most. Every
lesson covers **MySQL, PostgreSQL, and SQL Server** in its main dialect
notes, with additional **Oracle, SQLite, and DuckDB** notes in each
lesson's "Additional Dialect Notes" section.

## Interview Readiness

Every lesson includes an "Interview Questions" or "Interview Insight"
section drawn from the specific concept it teaches, and
[`INTERVIEW_GUIDE.md`](./INTERVIEW_GUIDE.md) collects 25 senior-level
questions in Q&A/trap/follow-up format. Before an interview, review:

- Lesson 01 & 02 — expect "walk me through what happens when you run a
  query" and "how do you read an EXPLAIN plan" as warm-up questions
- Lesson 03 — SARGability is one of the most common practical SQL
  interview topics at the mid-to-senior level
- Lesson 04 & 05 — join algorithm and subquery-rewrite questions are
  standard for data engineering and backend interviews
- Lesson 06 — anti-pattern recognition questions ("what's wrong with this
  query") are common in take-home / live-coding rounds
- Lesson 08 — parameter sniffing and cardinality estimation questions are
  the clearest signal of true senior/staff-level depth in an interview
- `PRACTICE_PROBLEMS.md` — work through all 8 before a real interview;
  Problem 7 (diagnosing from a plan description with no SQL shown) is the
  closest simulation of a real whiteboard question in this module
- `INTERVIEW_GUIDE.md` — full 25-question set, organized so each question
  names its trap and a natural follow-up

## References

- PostgreSQL Documentation — "Planner/Optimizer" and "Using EXPLAIN"
  chapters
- Use-the-index-luke.com — SARGability, indexing, and pagination reference
- MySQL Documentation — "Optimizing Queries with EXPLAIN"
- Microsoft Learn — SQL Server "Query Processing Architecture Guide"

## Estimated Completion Time

10–14 hours, including practice problems.

## Difficulty

Advanced. This is the first module in the handbook that assumes production
judgment, not just syntax fluency.

## Previous Module

[`14_VIEWS`](../14_VIEWS)

## Related Modules

[`03_Joins`](../03_Joins) · [`04_Subqueries`](../04_Subqueries) ·
[`06_CTEs`](../06_CTEs) · [`07_Window_Functions`](../07_Window_Functions)

## Contributor Experience

Extending this module? See [`CONTRIBUTING.md`](./CONTRIBUTING.md) for
naming conventions, documentation structure, SQL formatting rules, diagram
conventions, and the review checklist used to keep every lesson consistent
with the rest of the handbook.

## Module Completion Checklist

- [ ] Can explain the query execution lifecycle without notes
- [ ] Can read `EXPLAIN ANALYZE` output and identify the most expensive step
- [ ] Can identify a non-SARGable predicate on sight and rewrite it
- [ ] Can predict nested loop vs. hash join behavior for a given join
- [ ] Can rewrite a correlated subquery as a JOIN or `EXISTS` where appropriate
- [ ] Can name at least six production anti-patterns from memory
- [ ] Can explain how stale statistics or parameter sniffing produce a bad
      plan, and how to diagnose each
- [ ] Can apply all eight rewrite patterns in `09_QUERY_REWRITE_PATTERNS.md`
      and explain the reasoning behind each, not just the syntax
- [ ] Can design a benchmark that would survive scrutiny (cold/warm cache,
      multiple runs, variance) per `BENCHMARKING_GUIDE.md`
- [ ] Completed all practice problems in `PRACTICE_PROBLEMS.md`
- [ ] Worked through `INTERVIEW_GUIDE.md` and can answer without reading the
      "strong answer" text verbatim
